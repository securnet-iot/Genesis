#pragma once

#include <animal.hh>

class Cat : public Animal
{
public:
    Cat (std::string name);
};
