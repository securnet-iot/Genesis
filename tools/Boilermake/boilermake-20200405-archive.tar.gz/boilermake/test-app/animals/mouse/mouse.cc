#include "mouse.hh"

Mouse::Mouse (std::string name)
    :
    Animal(name)
{
    m_sound = "Squeak!";
}
