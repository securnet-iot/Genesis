#pragma once

#include <animal.hh>

class Dog : public Animal
{
public:
    Dog (std::string name);
};
