#pragma once

#include <dog.hh>

class Chihuahua : public Dog
{
public:
    Chihuahua (std::string name);
};
